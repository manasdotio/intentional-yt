/**
 * Recommendation Blocker for YouTube Focus Guard
 * Hides algorithmic recommendations and distracting elements.
 */

const isRecommendationBlockerHostSupported = (): boolean => {
  const hostname = window.location.hostname.toLowerCase();
  return hostname === 'www.youtube.com' || hostname === 'youtube.com';
};

class RecommendationBlocker {
  private static readonly navigationEventNames = ['yt-navigate-start', 'yt-navigate-finish', 'yt-page-data-updated'];
  private static instance: RecommendationBlocker;
  private isEnabled = true;
  private blockingTimeouts: number[] = [];
  private readonly boundScheduleBlockingPasses = () => this.scheduleBlockingPasses();

  static getInstance(): RecommendationBlocker {
    if (!RecommendationBlocker.instance) {
      RecommendationBlocker.instance = new RecommendationBlocker();
    }
    return RecommendationBlocker.instance;
  }

  constructor() {
    this.init();
  }

  private async init(): Promise<void> {
    await this.loadSettings();
    this.injectBlockingCSS();
    this.setupNavigationListeners();
    this.scheduleBlockingPasses();
  }

  private async loadSettings(): Promise<void> {
    this.isEnabled = true;
  }

  private injectBlockingCSS(): void {
    if (document.getElementById('yfg-blocking-css')) {
      return;
    }

    const style = document.createElement('style');
    style.id = 'yfg-blocking-css';
    style.textContent = `
      body:not(.yfg-research-active) #related,
      body:not(.yfg-research-active) ytd-watch-next-secondary-results-renderer,
      body:not(.yfg-research-active) #secondary ytd-compact-video-renderer,
      body:not(.yfg-research-active) ytd-item-section-renderer[section-identifier="related-items"],
      .ytp-ce-element,
      .ytp-endscreen-content,
      ytd-endscreen-element-renderer,
      .ytp-suggestion-set,
      .ytp-autonav-endscreen-upnext-container,
      ytd-reel-shelf-renderer,
      ytd-rich-shelf-renderer[is-shorts],
      ytd-browse[page-subtype="trending"],
      ytd-guide-entry-renderer[href="/feed/trending"] {
        display: none !important;
      }
    `;

    (document.head || document.documentElement).appendChild(style);
  }

  private setupNavigationListeners(): void {
    for (const eventName of RecommendationBlocker.navigationEventNames) {
      document.addEventListener(eventName, this.boundScheduleBlockingPasses as EventListener);
    }

    window.addEventListener('popstate', this.boundScheduleBlockingPasses);
  }

  private scheduleBlockingPasses(): void {
    this.clearBlockingTimeouts();

    const delays = [0, 150, 600, 1500, 3000];
    for (const delay of delays) {
      const timeoutId = window.setTimeout(() => {
        this.blockRecommendations();
        void this.filterRecommendations();
      }, delay);
      this.blockingTimeouts.push(timeoutId);
    }
  }

  private clearBlockingTimeouts(): void {
    for (const timeoutId of this.blockingTimeouts) {
      window.clearTimeout(timeoutId);
    }
    this.blockingTimeouts = [];
  }

  private blockRecommendations(): void {
    if (!this.isEnabled) {
      return;
    }

    this.blockHomeFeed();
    this.blockSidebarRecommendations();
    this.blockEndScreenRecommendations();
    this.blockShortsShelf();
    this.blockTrendingContent();
    this.disableAutoplay();
  }

  private blockHomeFeed(): void {
    const isResearch = document.body.classList.contains('yfg-research-active');

    if (!isResearch) {
      const homeFeedSelectors = [
        'ytd-rich-grid-renderer',
        'ytd-browse[page-subtype="home"]',
        '[role="main"] ytd-rich-grid-renderer',
        '#primary ytd-rich-grid-renderer',
      ];

      for (const selector of homeFeedSelectors) {
        const elements = document.querySelectorAll(selector);
        elements.forEach((element) => {
          if (this.isHomePage()) {
            this.hideElement(element as HTMLElement);
          }
        });
      }
    } else {
      const hiddenElements = document.querySelectorAll('[data-yfg-hidden="true"]');
      hiddenElements.forEach((element) => {
        if (element.tagName.toLowerCase() === 'ytd-rich-grid-renderer') {
          const htmlElement = element as HTMLElement;
          htmlElement.style.display = '';
          htmlElement.removeAttribute('data-yfg-hidden');
        }
      });
    }

    void this.showHomeMessage();
  }

  private isHomePage(): boolean {
    const url = window.location.href;
    return (url === 'https://www.youtube.com/' ||
      url === 'https://youtube.com/' ||
      url.includes('youtube.com/?') ||
      url.includes('youtube.com/feed/subscriptions')) &&
      !url.includes('/watch') &&
      !url.includes('/results');
  }

  private blockSidebarRecommendations(): void {
    this.hideElementsBySelectors([
      '#related',
      'ytd-watch-next-secondary-results-renderer',
      '#secondary ytd-compact-video-renderer',
      '[data-content="related"]',
      'ytd-item-section-renderer[section-identifier="related-items"]',
    ]);
  }

  private blockEndScreenRecommendations(): void {
    this.hideElementsBySelectors([
      '.ytp-ce-element',
      '.ytp-endscreen-content',
      'ytd-endscreen-element-renderer',
      '.ytp-suggestion-set',
      '.ytp-autonav-endscreen-upnext-container',
    ]);
  }

  private blockShortsShelf(): void {
    this.hideElementsBySelectors([
      'ytd-reel-shelf-renderer',
      '[aria-label*="Shorts"]',
      'ytd-rich-shelf-renderer[is-shorts]',
      '[href*="/shorts/"]',
    ]);
  }

  private blockTrendingContent(): void {
    this.hideElementsBySelectors([
      '[href="/feed/trending"]',
      'ytd-browse[page-subtype="trending"]',
      '[aria-label*="Trending"]',
      'ytd-guide-entry-renderer[href="/feed/trending"]',
    ]);
  }

  private disableAutoplay(): void {
    const autoplayButton = document.querySelector('[data-tooltip-text*="autoplay" i]') as HTMLElement | null;
    if (autoplayButton && autoplayButton.getAttribute('aria-pressed') === 'true') {
      autoplayButton.click();
    }

    const video = document.querySelector('video');
    if (video) {
      video.removeAttribute('autoplay');
    }
  }

  private hideElementsBySelectors(selectors: string[]): void {
    for (const selector of selectors) {
      const elements = document.querySelectorAll(selector);
      elements.forEach((element) => {
        this.hideElement(element as HTMLElement);
      });
    }
  }

  private hideElement(element: HTMLElement): void {
    if (!element || element.style.display === 'none') {
      return;
    }

    element.style.display = 'none';
    element.setAttribute('data-yfg-hidden', 'true');
  }

  private async showHomeMessage(): Promise<void> {
    if (!document.body || !this.isHomePage()) {
      return;
    }

    const existingMessage = document.querySelector('.yfg-home-message');
    if (existingMessage) {
      void this.updateHomeMessageStats();
      return;
    }

    const storage = (window as any).StorageManager.getInstance();
    const settings = await storage.getSettings();
    const recentTopics = Array.isArray(settings.research.recentTopics) ? settings.research.recentTopics : [];
    
    const todayWatchTime = settings.stats.todayWatchTime || 0;
    const todayResearchTime = settings.stats.todayResearchTime || 0;
    const todayEntertainmentTime = settings.stats.todayEntertainmentTime || 0;
    const intentionalityIndex = todayWatchTime > 0 
      ? Math.round((todayResearchTime / todayWatchTime) * 100) 
      : 100;

    const messageContainer = document.createElement('div');
    messageContainer.className = 'yfg-home-message';
    
    let recentHTML = '';
    if (recentTopics.length > 0) {
      recentHTML = `
        <div class="yfg-dashboard-recent">
          <div class="yfg-dashboard-recent-title">Resume Recent Topics</div>
          <div class="yfg-dashboard-topics-list">
            ${recentTopics.map((topic: string) => `<span class="yfg-dashboard-topic-pill" data-topic="${topic}">${topic}</span>`).join('')}
          </div>
        </div>
      `;
    }

    messageContainer.innerHTML = `
      <div class="yfg-dashboard-layout">
        <div class="yfg-dashboard-left">
          <h2 class="yfg-dashboard-greeting">Let's make this visit intentional</h2>
          <div class="yfg-dashboard-search-box">
            <span class="yfg-dashboard-search-icon">🔍</span>
            <input type="text" id="yfg-dashboard-search" class="yfg-dashboard-search-input" placeholder="What is your main intention for opening YouTube?" />
          </div>
          <div class="yfg-dashboard-buttons">
            <button class="yfg-dashboard-btn yfg-dashboard-btn-research" id="yfg-dash-research">
              🔬 Start Research
            </button>
            <button class="yfg-dashboard-btn yfg-dashboard-btn-leisure" id="yfg-dash-leisure">
              🎬 Start Leisure
            </button>
          </div>
          <div class="yfg-dashboard-quick-row">
            <a href="/feed/subscriptions" class="yfg-dashboard-link">✨ Quick Check Subscriptions</a>
            <span id="yfg-dash-cooldown-status" style="color: var(--yfg-color-text-muted)"></span>
          </div>
          ${recentHTML}
        </div>
        
        <div class="yfg-dashboard-right">
          <div class="yfg-dashboard-stats-label">Intentionality Index</div>
          <div class="yfg-progress-ring-container">
            <svg class="yfg-progress-ring" width="90" height="90">
              <defs>
                <linearGradient id="yfg-ring-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stop-color="#3b82f6" />
                  <stop offset="100%" stop-color="#8b5cf6" />
                </linearGradient>
              </defs>
              <circle class="yfg-progress-ring-circle-bg" cx="45" cy="45" r="38" />
              <circle class="yfg-progress-ring-circle-fill" cx="45" cy="45" r="38" />
            </svg>
            <span class="yfg-progress-ring-text" id="yfg-dash-ring-text">${intentionalityIndex}%</span>
          </div>
          <div class="yfg-dashboard-stats-summary">
            <div class="yfg-dashboard-stat-box">
              <span class="yfg-dashboard-stat-val" id="yfg-dash-stat-research">${Math.round(todayResearchTime / 60)}m</span>
              <span class="yfg-dashboard-stat-lbl">Research</span>
            </div>
            <div class="yfg-dashboard-stat-box">
              <span class="yfg-dashboard-stat-val" id="yfg-dash-stat-leisure">${Math.round(todayEntertainmentTime / 60)}m</span>
              <span class="yfg-dashboard-stat-lbl">Leisure</span>
            </div>
          </div>
        </div>
      </div>
    `;

    const mainContainer = document.querySelector('#primary') ||
      document.querySelector('[role="main"]') ||
      document.querySelector('#contents');

    if (mainContainer) {
      mainContainer.insertBefore(messageContainer, mainContainer.firstChild);
    } else {
      document.body.appendChild(messageContainer);
    }

    this.setProgressOffset(intentionalityIndex);

    const searchInput = messageContainer.querySelector('#yfg-dashboard-search') as HTMLInputElement | null;
    const researchBtn = messageContainer.querySelector('#yfg-dash-research') as HTMLButtonElement | null;
    const leisureBtn = messageContainer.querySelector('#yfg-dash-leisure') as HTMLButtonElement | null;
    
    const startResearch = async (topicVal: string) => {
      const topic = topicVal.trim();
      if (!topic) return;
      
      const keywords = topic.toLowerCase().split(/\s+/).filter((word) => word.length > 2);
      await storage.addRecentTopic(topic);
      await storage.saveSettings({
        research: {
          mode: 'research',
          currentTopic: keywords,
          sessionStart: Date.now()
        }
      });
      
      window.location.href = `https://www.youtube.com/results?search_query=${encodeURIComponent(topic)}`;
    };

    const startLeisure = async (topicVal: string) => {
      await storage.saveSettings({
        research: {
          mode: 'entertainment',
          currentTopic: [],
          sessionStart: Date.now()
        }
      });
      await storage.updateBrowsingMode({
        active: true,
        startTime: Date.now(),
        duration: 15 * 60 * 1000,
        extensionsUsed: 0,
        cooldownUntil: 0
      });
      
      window.location.reload();
    };

    if (researchBtn && searchInput) {
      researchBtn.addEventListener('click', () => void startResearch(searchInput.value));
    }

    if (leisureBtn && searchInput) {
      leisureBtn.addEventListener('click', () => void startLeisure(searchInput.value));
    }

    if (searchInput) {
      searchInput.addEventListener('keypress', (e: KeyboardEvent) => {
        if (e.key === 'Enter') {
          void startResearch(searchInput.value);
        }
      });
    }

    const pills = messageContainer.querySelectorAll('.yfg-dashboard-topic-pill');
    pills.forEach(pill => {
      pill.addEventListener('click', () => {
        const topic = pill.getAttribute('data-topic');
        if (topic) {
          void startResearch(topic);
        }
      });
    });
  }

  private async updateHomeMessageStats(): Promise<void> {
    const ringText = document.getElementById('yfg-dash-ring-text');
    const researchStat = document.getElementById('yfg-dash-stat-research');
    const leisureStat = document.getElementById('yfg-dash-stat-leisure');
    if (!ringText || !researchStat || !leisureStat) return;

    const storage = (window as any).StorageManager.getInstance();
    const settings = await storage.getSettings();
    const todayWatchTime = settings.stats.todayWatchTime || 0;
    const todayResearchTime = settings.stats.todayResearchTime || 0;
    const todayEntertainmentTime = settings.stats.todayEntertainmentTime || 0;
    
    const intentionalityIndex = todayWatchTime > 0 
      ? Math.round((todayResearchTime / todayWatchTime) * 100) 
      : 100;

    ringText.textContent = `${intentionalityIndex}%`;
    researchStat.textContent = `${Math.round(todayResearchTime / 60)}m`;
    leisureStat.textContent = `${Math.round(todayEntertainmentTime / 60)}m`;
    this.setProgressOffset(intentionalityIndex);
  }

  private setProgressOffset(percent: number): void {
    const circle = document.querySelector('.yfg-progress-ring-circle-fill') as SVGCircleElement | null;
    if (!circle) return;
    const rAttr = circle.getAttribute('r');
    const radius = rAttr ? parseFloat(rAttr) : 38;
    const circumference = radius * 2 * Math.PI;
    
    circle.style.strokeDasharray = `${circumference} ${circumference}`;
    const offset = circumference - (percent / 100) * circumference;
    circle.style.strokeDashoffset = offset.toString();
  }

  private async filterRecommendations(): Promise<void> {
    const storage = (window as any).StorageManager.getInstance();
    const settings = await storage.getSettings();
    
    const isResearch = settings.research.mode === 'research';
    const topicKeywords = settings.research.currentTopic;

    if (!isResearch || !topicKeywords || topicKeywords.length === 0) {
      document.body.classList.remove('yfg-research-active');
      this.clearFeedFilters();
      return;
    }

    document.body.classList.add('yfg-research-active');

    const feedItems = document.querySelectorAll('ytd-rich-item-renderer');
    feedItems.forEach(item => this.evaluateAndFilterItem(item as HTMLElement, topicKeywords, settings.research.allowedChannels));

    const sidebarItems = document.querySelectorAll('ytd-compact-video-renderer');
    sidebarItems.forEach(item => this.evaluateAndFilterItem(item as HTMLElement, topicKeywords, settings.research.allowedChannels));
  }

  private clearFeedFilters(): void {
    const blurred = document.querySelectorAll('.yfg-feed-blurred-item');
    blurred.forEach(el => {
      el.classList.remove('yfg-feed-blurred-item');
      const badge = el.querySelector('.yfg-feed-drift-badge');
      if (badge) badge.remove();
    });
  }

  private evaluateAndFilterItem(item: HTMLElement, keywords: string[], allowedChannels: string[]): void {
    if (item.classList.contains('yfg-feed-blurred-item') || item.querySelector('.yfg-feed-drift-badge')) {
      return;
    }

    const titleEl = item.querySelector('#video-title, #video-title-link, h3, h4');
    const titleText = titleEl ? (titleEl.textContent || '').trim() : '';
    if (!titleText) return;

    const channelEl = item.querySelector('ytd-channel-name a, #channel-name a, #byline a');
    const channelText = channelEl ? (channelEl.textContent || '').trim().toLowerCase() : '';

    const isAllowedChannel = allowedChannels && allowedChannels.some(ch => ch.toLowerCase() === channelText);
    
    if (isAllowedChannel) {
      return;
    }

    const isRelated = this.isTitleRelated(titleText, keywords);
    if (!isRelated) {
      item.classList.add('yfg-feed-blurred-item');
      
      const badge = document.createElement('div');
      badge.className = 'yfg-feed-drift-badge';
      
      const badgeTitle = document.createElement('p');
      badgeTitle.className = 'yfg-feed-drift-badge-title';
      badgeTitle.textContent = 'Topic Drift';
      
      const badgeDesc = document.createElement('p');
      badgeDesc.className = 'yfg-feed-drift-badge-desc';
      badgeDesc.textContent = 'Unrelated to your research topic.';

      const bypassBtn = document.createElement('button');
      bypassBtn.className = 'yfg-feed-drift-btn';
      bypassBtn.textContent = 'Reveal Video';
      bypassBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        item.classList.remove('yfg-feed-blurred-item');
        badge.remove();
        const link = item.querySelector('a[href*="/watch"]') as HTMLAnchorElement | null;
        if (link && (window as any).TopicGuard) {
          (window as any).TopicGuard.getInstance().markVideoAllowedOnce(link.href);
        }
      });

      badge.append(badgeTitle, badgeDesc, bypassBtn);
      item.appendChild(badge);
    }
  }

  private isTitleRelated(title: string, keywords: string[]): boolean {
    const titleLower = title.toLowerCase();
    
    const normalize = (txt: string) => txt.replace(/[^\w\s]/g, ' ').replace(/\s+/g, ' ').trim();
    const titleNormalized = normalize(titleLower);
    const titleTokens = titleNormalized.split(' ').filter(w => w.length > 2);
    
    let matches = 0;
    for (const kw of keywords) {
      const kwLower = kw.toLowerCase();
      if (kwLower.includes(' ')) {
        if (titleLower.includes(kwLower)) {
          return true;
        }
      }
      
      if (titleTokens.includes(kwLower) || titleLower.includes(kwLower)) {
        matches++;
      }
    }

    return matches > 0;
  }

  enable(): void {
    this.isEnabled = true;
    this.blockRecommendations();
  }

  disable(): void {
    this.isEnabled = false;
    this.showHiddenElements();
  }

  toggle(): void {
    if (this.isEnabled) {
      this.disable();
    } else {
      this.enable();
    }
  }

  private showHiddenElements(): void {
    const hiddenElements = document.querySelectorAll('[data-yfg-hidden="true"]');
    hiddenElements.forEach((element) => {
      const htmlElement = element as HTMLElement;
      htmlElement.style.display = '';
      htmlElement.removeAttribute('data-yfg-hidden');
    });

    const homeMessage = document.querySelector('.yfg-home-message');
    if (homeMessage) {
      homeMessage.remove();
    }
  }

  destroy(): void {
    this.clearBlockingTimeouts();
    this.showHiddenElements();
  }
}

(window as any).RecommendationBlocker = RecommendationBlocker;
if (isRecommendationBlockerHostSupported()) {
  RecommendationBlocker.getInstance();
}
