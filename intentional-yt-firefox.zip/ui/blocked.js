class BlockedPageController {
  constructor() {
    this.storage = null;
    this.timeUtils = null;
    this.content = null;
    this.init();
  }

  async init() {
    await this.waitForDependencies();

    this.storage = window.StorageManager.getInstance();
    this.timeUtils = window.TimeUtils.getInstance();
    this.content = document.getElementById('blocked-content');
    this.setupActions();

    const reason = this.getBlockReason();
    await this.renderBlockedContent(reason);

    if (reason === 'nightlock') {
      this.startCountdown();
    } else if (reason === 'browsing-cooldown') {
      this.startBrowsingCooldownCountdown();
    }
  }

  async waitForDependencies() {
    return new Promise((resolve) => {
      const checkDependencies = () => {
        if (window.StorageManager && window.TimeUtils) {
          resolve();
        } else {
          setTimeout(checkDependencies, 100);
        }
      };
      checkDependencies();
    });
  }

  getBlockReason() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('reason') || 'unknown';
  }

  setupActions() {
    document.addEventListener('click', async (event) => {
      const target = event.target;
      const action = target && target.getAttribute ? target.getAttribute('data-action') : null;

      if (!action) {
        return;
      }

      if (action === 'go-home') {
        window.location.href = 'https://www.youtube.com';
      } else if (action === 'reload') {
        window.location.reload();
      } else if (action === 'start-research') {
        await this.handleStartResearch();
      }
    });

    document.addEventListener('keydown', async (event) => {
      if (event.key === 'Enter' && event.target && event.target.id === 'blocked-topic-input') {
        event.preventDefault();
        await this.handleStartResearch();
      }
    });
  }

  async handleStartResearch() {
    const input = document.getElementById('blocked-topic-input');
    const topicValue = input ? input.value.trim() : '';
    if (!topicValue) {
      if (input) {
        input.focus();
        input.placeholder = 'Enter a research topic...';
      }
      return;
    }

    const parts = topicValue.includes(',') || topicValue.includes('\n')
      ? topicValue.split(/[\n,]+/)
      : topicValue.split(/\s+/);
    const currentTopic = [...new Set(parts.map((part) => part.trim().toLowerCase()).filter(Boolean))];

    if (currentTopic.length > 0) {
      await this.storage.addRecentTopic(topicValue);

      await this.storage.saveSettings({
        research: {
          mode: 'research',
          currentTopic: currentTopic,
          sessionStart: Date.now()
        }
      });

      await this.storage.setBlocked(null);

      const query = currentTopic.join(' ');
      window.location.href = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    }
  }

  createStatsWidget(settings) {
    const todayWatchTime = settings.stats.todayWatchTime || 0;
    const todayResearchTime = settings.stats.todayResearchTime || 0;
    const todayEntertainmentTime = settings.stats.todayEntertainmentTime || 0;
    const intentionalityIndex = todayWatchTime > 0
      ? Math.round((todayResearchTime / todayWatchTime) * 100)
      : 100;

    const widget = this.createElement('div', 'yfg-blocked-stats-widget');
    widget.style.margin = '24px 0';
    widget.style.padding = '18px';
    widget.style.borderRadius = '14px';
    widget.style.background = 'rgba(255, 255, 255, 0.03)';
    widget.style.border = '1px solid rgba(255, 255, 255, 0.05)';
    widget.style.display = 'flex';
    widget.style.flexDirection = 'column';
    widget.style.gap = '12px';

    const titleRow = this.createElement('div');
    titleRow.style.display = 'flex';
    titleRow.style.justifyContent = 'space-between';
    titleRow.style.alignItems = 'center';
    
    const titleLabel = this.createElement('span', '', "Today's Intentionality Index");
    titleLabel.style.fontSize = '12px';
    titleLabel.style.fontWeight = '600';
    titleLabel.style.color = 'var(--yfg-color-text-muted)';
    titleLabel.style.textTransform = 'uppercase';
    titleLabel.style.letterSpacing = '0.05em';

    const indexValue = this.createElement('span', '', `${intentionalityIndex}%`);
    indexValue.style.fontSize = '18px';
    indexValue.style.fontWeight = '800';
    indexValue.style.color = 'var(--yfg-color-text)';
    
    titleRow.append(titleLabel, indexValue);

    const progressBarContainer = this.createElement('div');
    progressBarContainer.style.height = '6px';
    progressBarContainer.style.background = 'rgba(255, 255, 255, 0.08)';
    progressBarContainer.style.borderRadius = '3px';
    progressBarContainer.style.overflow = 'hidden';

    const progressBar = this.createElement('div');
    progressBar.style.height = '100%';
    progressBar.style.width = `${intentionalityIndex}%`;
    progressBar.style.background = 'linear-gradient(90deg, #3b82f6, #8b5cf6)';
    progressBar.style.borderRadius = '3px';
    progressBarContainer.appendChild(progressBar);

    const detailRows = this.createElement('div');
    detailRows.style.display = 'grid';
    detailRows.style.gridTemplateColumns = 'repeat(2, 1fr)';
    detailRows.style.gap = '16px';
    detailRows.style.marginTop = '4px';

    const formatMins = (secs) => {
      const mins = Math.round(secs / 60);
      return `${mins}m`;
    };

    const researchBox = this.createElement('div');
    researchBox.style.textAlign = 'left';
    
    const researchLabel = this.createElement('div', '', 'Focused Research');
    researchLabel.style.fontSize = '11px';
    researchLabel.style.color = 'var(--yfg-color-text-muted)';
    
    const researchVal = this.createElement('div', '', formatMins(todayResearchTime));
    researchVal.style.fontSize = '16px';
    researchVal.style.fontWeight = '700';
    researchVal.style.color = '#60a5fa';
    researchBox.append(researchLabel, researchVal);

    const leisureBox = this.createElement('div');
    leisureBox.style.textAlign = 'right';

    const leisureLabel = this.createElement('div', '', 'Leisure Watch Time');
    leisureLabel.style.fontSize = '11px';
    leisureLabel.style.color = 'var(--yfg-color-text-muted)';

    const leisureVal = this.createElement('div', '', formatMins(todayEntertainmentTime));
    leisureVal.style.fontSize = '16px';
    leisureVal.style.fontWeight = '700';
    leisureVal.style.color = '#c084fc';
    leisureBox.append(leisureLabel, leisureVal);

    detailRows.append(researchBox, leisureBox);

    widget.append(titleRow, progressBarContainer, detailRows);
    return widget;
  }

  createResearchForm() {
    const form = this.createElement('div', 'yfg-blocked-research-form');
    form.style.marginTop = '24px';
    form.style.padding = '18px';
    form.style.borderRadius = '14px';
    form.style.background = 'rgba(255, 255, 255, 0.02)';
    form.style.border = '1px solid rgba(255, 255, 255, 0.04)';
    form.style.textAlign = 'left';

    const title = this.createElement('h3', '', 'Switch to Research Mode');
    title.style.margin = '0 0 6px 0';
    title.style.fontSize = '13px';
    title.style.fontWeight = '600';
    title.style.color = 'var(--yfg-color-text)';

    const subtitle = this.createElement('p', '', 'Turn this block into a learning opportunity. Enter a topic to start a focused session.');
    subtitle.style.margin = '0 0 14px 0';
    subtitle.style.fontSize = '12px';
    subtitle.style.color = 'var(--yfg-color-text-muted)';
    subtitle.style.lineHeight = '1.4';

    const inputRow = this.createElement('div');
    inputRow.style.display = 'flex';
    inputRow.style.gap = '10px';

    const input = this.createElement('input', 'input-field');
    input.id = 'blocked-topic-input';
    input.type = 'text';
    input.placeholder = 'e.g. Next.js tutorial, cooking techniques';
    input.style.flex = '1';

    const button = this.createElement('button', 'yfg-btn yfg-btn-primary', 'Start Research');
    button.type = 'button';
    button.dataset.action = 'start-research';
    button.style.flex = '0 0 auto';
    button.style.padding = '10px 16px';

    inputRow.append(input, button);
    form.append(title, subtitle, inputRow);
    return form;
  }

  formatClock(timeValue) {
    if (!timeValue || !timeValue.includes(':')) {
      return timeValue || '--';
    }

    const [hoursText, minutes] = timeValue.split(':');
    const hours = parseInt(hoursText, 10);
    const suffix = hours >= 12 ? 'PM' : 'AM';
    const normalizedHours = hours % 12 || 12;
    return `${normalizedHours}:${minutes} ${suffix}`;
  }

  async renderBlockedContent(reason) {
    let content;
    const settings = await this.storage.getSettings();

    switch (reason) {
      case 'nightlock':
        content = await this.getNightLockContent();
        break;
      case 'entertainment-limit':
        content = this.getEntertainmentLimitContent();
        break;
      case 'shorts':
        content = this.getShortsBlockContent();
        break;
      case 'session-limit':
        content = this.getSessionLimitContent();
        break;
      case 'browsing-cooldown':
        content = await this.getBrowsingCooldownContent();
        break;
      default:
        content = this.getGenericBlockContent();
    }

    if (this.content && content) {
      // Append stats widget for non-nightlock states
      if (reason !== 'nightlock') {
        const statsWidget = this.createStatsWidget(settings);
        content.appendChild(statsWidget);

        // Append research form for interactive states
        if (reason === 'entertainment-limit' || reason === 'shorts' || reason === 'session-limit' || reason === 'browsing-cooldown') {
          const researchForm = this.createResearchForm();
          content.appendChild(researchForm);
        }
      }

      this.content.replaceChildren(content);
    }
  }

  createElement(tagName, className, textContent) {
    const element = document.createElement(tagName);
    if (className) {
      element.className = className;
    }
    if (typeof textContent === 'string') {
      element.textContent = textContent;
    }
    return element;
  }

  createList(items) {
    const list = this.createElement('ul', 'yfg-blocked-list');
    for (const itemText of items) {
      const item = document.createElement('li');
      item.textContent = itemText;
      list.appendChild(item);
    }
    return list;
  }

  createPanel(label, items) {
    const panel = this.createElement('div', 'yfg-blocked-panel');
    panel.append(this.createElement('div', 'yfg-detail-label', label), this.createList(items));
    return panel;
  }

  createActions(actions) {
    const actionContainer = this.createElement('div', 'yfg-blocked-actions');
    for (const actionConfig of actions) {
      const button = this.createElement('button', actionConfig.className, actionConfig.label);
      button.type = 'button';
      button.dataset.action = actionConfig.action;
      actionContainer.appendChild(button);
    }
    return actionContainer;
  }

  createCountdown(label, id, initialValue, note) {
    const wrap = this.createElement('div', 'yfg-blocked-countdown-wrap');
    const countdown = this.createElement('div', 'yfg-blocked-countdown', initialValue);
    countdown.id = id;
    wrap.append(
      this.createElement('div', 'yfg-blocked-countdown-label', label),
      countdown,
      this.createElement('div', 'yfg-inline-note', note)
    );
    return wrap;
  }

  createBlockedView(config) {
    const fragment = document.createDocumentFragment();
    fragment.append(
      this.createElement('div', 'yfg-blocked-icon', config.icon),
      this.createElement('div', 'yfg-blocked-eyebrow', config.eyebrow),
      this.createElement('h1', 'yfg-blocked-title', config.title),
      this.createElement('p', 'yfg-blocked-message', config.message)
    );

    if (config.meta) {
      fragment.appendChild(this.createElement('p', 'yfg-blocked-meta', config.meta));
    }

    if (config.countdown) {
      fragment.appendChild(this.createCountdown(
        config.countdown.label,
        config.countdown.id,
        config.countdown.initialValue,
        config.countdown.note
      ));
    }

    if (config.actions && config.actions.length > 0) {
      fragment.appendChild(this.createActions(config.actions));
    }

    if (config.panel) {
      fragment.appendChild(this.createPanel(config.panel.label, config.panel.items));
    }

    return fragment;
  }

  async getNightLockContent() {
    const settings = await this.storage.getSettings();
    const endTime = settings.nightLock.endTime;
    const currentTime = this.timeUtils.getCurrentTime();

    return this.createBlockedView({
      icon: '🌙',
      eyebrow: 'Night Lock',
      title: 'YouTube Locked',
      message: 'YouTube is blocked during your sleep hours so late-night scrolling does not steal tomorrow\'s focus.',
      meta: `Current time: ${currentTime}`,
      countdown: {
        label: 'Unlocks in',
        id: 'countdown',
        initialValue: '--',
        note: `Available again at ${this.formatClock(endTime)}`
      },
      panel: {
        label: 'Reset instead',
        items: [
          'Dim the lights and put the phone away.',
          'Read something slow and low-stimulation.',
          'Try a short stretch or breathing routine.',
          'Skip caffeine and bright screens before bed.'
        ]
      }
    });
  }

  getEntertainmentLimitContent() {
    return this.createBlockedView({
      icon: '⏰',
      eyebrow: 'Daily Limit',
      title: 'Daily Limit Reached',
      message: 'You have used all of today\'s entertainment time. The limit resets at midnight.',
      panel: {
        label: 'Better next step',
        items: [
          'Start a focused research session.',
          'Read or write for 10 minutes first.',
          'Take a walk or stretch before returning.',
          'Come back with one intentional search.'
        ]
      }
    });
  }

  getShortsBlockContent() {
    return this.createBlockedView({
      icon: '🚫',
      eyebrow: 'Shorts Guard',
      title: 'Shorts Blocked',
      message: 'Shorts are disabled to keep YouTube from collapsing into an endless swipe loop.',
      actions: [
        { className: 'yfg-btn yfg-btn-primary', action: 'go-home', label: 'Go to YouTube Home' }
      ],
      panel: {
        label: 'Try instead',
        items: [
          'Search for one specific topic.',
          'Watch a full tutorial or lecture.',
          'Queue one intentional long-form video.',
          'Use playlists instead of swiping feeds.'
        ]
      }
    });
  }

  getSessionLimitContent() {
    return this.createBlockedView({
      icon: '🛑',
      eyebrow: 'Session Limit',
      title: 'Session Limit Reached',
      message: 'You hit the maximum continuous watch time. Take a real pause before you come back.',
      actions: [
        { className: 'yfg-btn yfg-btn-primary', action: 'go-home', label: 'I\'ve Taken a Break' }
      ],
      panel: {
        label: 'Reset your focus',
        items: [
          'Step away for five to ten minutes.',
          'Move your body and hydrate.',
          'Decide what you actually need from YouTube next.'
        ]
      }
    });
  }

  async getBrowsingCooldownContent() {
    const settings = await this.storage.getSettings();
    const remainingMs = Math.max(0, settings.browsingMode.cooldownUntil - Date.now());
    const remainingMinutes = Math.ceil(remainingMs / 60000);

    return this.createBlockedView({
      icon: '⏳',
      eyebrow: 'Browsing Cooldown',
      title: 'Browsing Session Ended',
      message: 'Browsing is paused after two extensions. Give the algorithm some distance before coming back.',
      countdown: {
        label: 'Available again in',
        id: 'browsing-cooldown-countdown',
        initialValue: `${remainingMinutes}m`,
        note: 'Browsing is blocked for 30 minutes after two extensions.'
      },
      panel: {
        label: 'Reset the loop',
        items: [
          'Leave YouTube entirely for a while.',
          'Do one offline task before coming back.',
          'Return with a specific purpose.'
        ]
      }
    });
  }

  getGenericBlockContent() {
    return this.createBlockedView({
      icon: '🎯',
      eyebrow: 'Focus Guard',
      title: 'Focus Guard Active',
      message: 'YouTube is currently restricted to protect attention and reduce passive drift.',
      panel: {
        label: 'Alternatives',
        items: [
          'Read something useful.',
          'Work on your current task list.',
          'Move, stretch, or go outside.',
          'Return later with one clear query.'
        ]
      }
    });
  }

  async startCountdown() {
    const settings = await this.storage.getSettings();
    const endTime = settings.nightLock.endTime;

    const updateCountdown = () => {
      const { hours, minutes } = this.timeUtils.timeUntilUnlock(endTime);
      const countdownElement = document.getElementById('countdown');

      if (!countdownElement) {
        return;
      }

      if (hours === 0 && minutes === 0) {
        const isLockActive = this.timeUtils.isNightLockActive(
          settings.nightLock.startTime,
          settings.nightLock.endTime
        );

        if (!isLockActive) {
          window.location.href = 'https://www.youtube.com';
          return;
        }
      }

      countdownElement.textContent = this.timeUtils.getUnlockCountdown(endTime);
    };

    updateCountdown();
    setInterval(updateCountdown, 60000);
  }

  async startBrowsingCooldownCountdown() {
    const updateCountdown = async () => {
      const settings = await this.storage.getSettings();
      const remainingMs = Math.max(0, settings.browsingMode.cooldownUntil - Date.now());
      const countdownElement = document.getElementById('browsing-cooldown-countdown');

      if (!countdownElement) {
        return;
      }

      if (remainingMs <= 0) {
        await this.storage.updateBrowsingMode({ cooldownUntil: 0 });
        await this.storage.setBlocked(null);
        window.location.href = 'https://www.youtube.com';
        return;
      }

      countdownElement.textContent = this.timeUtils.formatTime(Math.ceil(remainingMs / 1000));
    };

    await updateCountdown();
    setInterval(() => {
      void updateCountdown();
    }, 1000);
  }
}

new BlockedPageController();